# Import required libraries
import pandas as pd
import numpy as np
from sklearn.model_selection import train_test_split, GridSearchCV, learning_curve
from sklearn.linear_model import LogisticRegression
from sklearn.metrics import accuracy_score, classification_report, confusion_matrix
from sklearn.feature_selection import RFE
from sklearn.preprocessing import StandardScaler
import matplotlib.pyplot as plt
import joblib

# Load dataset
df = pd.read_csv(r'/Users/judyahmed/Downloads/breast-cancer.csv.xls')

# Drop unnecessary columns
df.drop(columns=["id"], inplace=True, errors="ignore")

# Encode 'M' as 1 and 'B' as 0 (malignant vs benign)
if "diagnosis" in df.columns:
    df["diagnosis"] = df["diagnosis"].apply(lambda x: 1 if x == "M" else 0)

# Handle missing values (fill numeric columns with mean)
df.fillna(df.mean(), inplace=True)

# Remove highly correlated features (above 90%)
corr_matrix = df.corr()
high_corr = set()

for i in range(len(corr_matrix.columns)):
    for j in range(i):
        if abs(corr_matrix.iloc[i, j]) > 0.9:
            high_corr.add(corr_matrix.columns[i])

df.drop(columns=high_corr, inplace=True)

# Remove duplicates
df = df.drop_duplicates()

# Check for skewness and apply transformation if necessary
skewed_features = df.drop(columns=["diagnosis"]).skew().abs()
skewed_cols = skewed_features[skewed_features > 1].index  # Threshold: 1 for high skewness

# Apply log transformation to highly skewed features
df[skewed_cols] = np.log1p(df[skewed_cols])

# Split dataset into features (X) and target variable (y)
X = df.drop(columns=["diagnosis"])
y = df["diagnosis"]

# **✅ Apply train-test split BEFORE scaling**
X_train, X_test, y_train, y_test = train_test_split(X, y, test_size=0.2, random_state=42, stratify=y)

# **✅ Apply feature scaling AFTER train-test split**
scaler = StandardScaler()
X_train_scaled = scaler.fit_transform(X_train)
X_test_scaled = scaler.transform(X_test)

# Save the scaler for use in testing
joblib.dump(scaler, '/Users/judyahmed/Downloads/scaler.pkl')

# **✅ Apply feature selection AFTER scaling**
model = LogisticRegression(random_state=42, class_weight='balanced', max_iter=5000)
rfe = RFE(model, n_features_to_select=10)  # Initialize RFE
X_train_selected = rfe.fit_transform(X_train_scaled, y_train)
X_test_selected = rfe.transform(X_test_scaled)

# Save selected features
selected_features = X_train.columns[rfe.support_]
joblib.dump(selected_features, '/Users/judyahmed/Downloads/selected_features.pkl')

# **✅ Fine-tune the model using GridSearchCV**
param_grid = {
    'C': [0.001, 0.01, 0.1, 1, 10, 100],
    'penalty': ['l1', 'l2'],
    'solver': ['liblinear', 'saga']
}

grid_search = GridSearchCV(estimator=model, param_grid=param_grid, cv=7, scoring='accuracy', error_score='raise')
grid_search.fit(X_train_selected, y_train)

# Get the best model
best_model = grid_search.best_estimator_

# **✅ Plot the learning curve BEFORE saving the model**
def plot_learning_curve(estimator, X, y, cv=7):
    train_sizes, train_scores, test_scores = learning_curve(
        estimator, X, y, cv=cv, scoring="accuracy", train_sizes=np.linspace(0.1, 1.0, 10), n_jobs=-1
    )
    train_mean = np.mean(train_scores, axis=1)
    train_std = np.std(train_scores, axis=1)
    test_mean = np.mean(test_scores, axis=1)
    test_std = np.std(test_scores, axis=1)

    plt.figure(figsize=(8, 6))
    plt.plot(train_sizes, train_mean, label="Training Accuracy", marker="o", color="blue")
    plt.fill_between(train_sizes, train_mean - train_std, train_mean + train_std, color="blue", alpha=0.2)
    plt.plot(train_sizes, test_mean, label="Validation Accuracy", marker="s", color="green")
    plt.fill_between(train_sizes, test_mean - test_std, test_mean + test_std, color="green", alpha=0.2)
    plt.xlabel("Training Set Size")
    plt.ylabel("Accuracy")
    plt.title("Learning Curve")
    plt.legend()
    plt.grid()
    plt.show()

# **Plot learning curve**
plot_learning_curve(best_model, X_train_selected, y_train)

# **Evaluate the fine-tuned model on the test set**
y_pred_tuned = best_model.predict(X_test_selected)

print("\nFine-Tuned Model Evaluation:")
print("Accuracy:", accuracy_score(y_test, y_pred_tuned))
print("\nClassification Report:\n", classification_report(y_test, y_pred_tuned))
print("\nConfusion Matrix:\n", confusion_matrix(y_test, y_pred_tuned))

# **Save the trained model and feature selector**
joblib.dump(best_model, '/Users/judyahmed/Downloads/breast_cancer_model.pkl')
joblib.dump(rfe, '/Users/judyahmed/Downloads/feature_selector.pkl')

print("\n✅ Model training completed! Model and feature selector saved successfully.")
